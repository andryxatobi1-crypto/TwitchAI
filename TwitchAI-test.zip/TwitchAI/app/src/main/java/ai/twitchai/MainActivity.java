package ai.twitchai;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;

public class MainActivity extends Activity {
    static final String VOT = "https://raw.githubusercontent.com/ilyhalight/voice-over-translation/master/dist/vot.user.js";
    static final String DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
    static final int IMMERSIVE = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;

    WebView web;
    FrameLayout root;
    TextView dbg, pcBtn;
    View customView;
    WebChromeClient.CustomViewCallback customCb;
    String shim = "";
    String script = "";
    String mobileUa = "";
    boolean desktop = false;
    final ArrayList<String> lines = new ArrayList<>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        root = new FrameLayout(this);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));

        dbg = new TextView(this);
        dbg.setTextSize(10);
        dbg.setTextColor(Color.GREEN);
        dbg.setBackgroundColor(0xAA000000);
        dbg.setPadding(12, 8, 12, 8);
        dbg.setOnClickListener(v -> v.setVisibility(View.GONE));
        root.addView(dbg, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START));

        pcBtn = new TextView(this);
        pcBtn.setText("ПК");
        pcBtn.setTextColor(Color.WHITE);
        pcBtn.setBackgroundColor(0xCC6441A5);
        pcBtn.setPadding(28, 18, 28, 18);
        pcBtn.setOnClickListener(v -> toggleDesktop());
        root.addView(pcBtn, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END));
        setContentView(root);

        WebView.setWebContentsDebuggingEnabled(true);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        mobileUa = s.getUserAgentString().replace("; wv", "");
        s.setUserAgentString(mobileUa);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                log("страница: " + url);
                if (desktop) {
                    v.evaluateJavascript("(function(){var m=document.querySelector('meta[name=viewport]');if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m)}m.setAttribute('content','width=1280')})()", null);
                }
                inject();
                v.postDelayed(() -> check(), 6000);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage m) {
                String t = m.message();
                String tl = t.toLowerCase();
                String src = m.sourceId() == null ? "" : m.sourceId();
                boolean ours = tl.contains("vot") || tl.contains("gm_") || tl.contains("androidbridge") || tl.contains("yandex");
                boolean err = m.messageLevel() == ConsoleMessage.MessageLevel.ERROR && src.isEmpty();
                if (ours || err) log("[" + m.messageLevel() + "] " + t);
                return true;
            }

            @Override
            public void onShowCustomView(View v, CustomViewCallback cb) {
                customView = v;
                customCb = cb;
                root.addView(v, new FrameLayout.LayoutParams(-1, -1));
                web.setVisibility(View.GONE);
                getWindow().getDecorView().setSystemUiVisibility(IMMERSIVE);
            }

            @Override
            public void onHideCustomView() {
                if (customView == null) return;
                root.removeView(customView);
                customView = null;
                web.setVisibility(View.VISIBLE);
                getWindow().getDecorView().setSystemUiVisibility(0);
                if (customCb != null) customCb.onCustomViewHidden();
            }
        });

        new Thread(() -> {
            shim = readAsset("shim.js");
            script = fetchScript();
            log("скрипт перевода: " + script.length() + " символов");
            runOnUiThread(() -> {
                if (script.isEmpty()) {
                    Toast.makeText(this, "Не удалось загрузить скрипт перевода", Toast.LENGTH_LONG).show();
                }
                web.loadUrl("https://www.twitch.tv");
            });
        }).start();
    }

    void toggleDesktop() {
        desktop = !desktop;
        WebSettings s = web.getSettings();
        s.setUserAgentString(desktop ? DESKTOP_UA : mobileUa);
        s.setUseWideViewPort(desktop);
        s.setLoadWithOverviewMode(desktop);
        pcBtn.setText(desktop ? "ТЕЛ" : "ПК");
        log("режим: " + (desktop ? "ПК" : "телефон"));
        web.reload();
    }

    void log(final String msg) {
        runOnUiThread(() -> {
            String m = msg.length() > 150 ? msg.substring(0, 150) : msg;
            lines.add(m);
            while (lines.size() > 8) lines.remove(0);
            dbg.setText(TextUtils.join("\n", lines));
        });
    }

    void check() {
        web.evaluateJavascript("(function(){return document.querySelectorAll('[class*=\"vot-\"]').length+' vot-элементов, GM='+(typeof GM_xmlhttpRequest)+', video='+document.querySelectorAll('video').length})()",
                r -> log("проверка: " + r));
    }

    void inject() {
        if (script.isEmpty()) return;
        web.evaluateJavascript("if(!window.__tai){window.__tai=1;\n" + shim + "\n" + script + "\n}", null);
    }

    String readAsset(String name) {
        try {
            return new String(readAll(getAssets().open(name)), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    String fetchScript() {
        File f = new File(getFilesDir(), "vot.js");
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(VOT).openConnection();
            c.setConnectTimeout(10000);
            c.setReadTimeout(20000);
            byte[] d = readAll(c.getInputStream());
            FileOutputStream fo = new FileOutputStream(f);
            fo.write(d);
            fo.close();
        } catch (Exception e) {
            // no internet: use the cached copy if there is one
        }
        try {
            return new String(readAll(new FileInputStream(f)), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        in.close();
        return o.toByteArray();
    }

    String doRequest(String json) {
        JSONObject o = new JSONObject();
        try {
            JSONObject r = new JSONObject(json);
            String u = r.getString("url");
            if (!u.startsWith("https://")) throw new Exception("https only");
            HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
            c.setRequestMethod(r.optString("method", "GET"));
            c.setConnectTimeout(15000);
            c.setReadTimeout(60000);
            JSONObject h = r.optJSONObject("headers");
            if (h != null) {
                Iterator<String> it = h.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    c.setRequestProperty(k, h.optString(k));
                }
            }
            if (!r.isNull("body")) {
                c.setDoOutput(true);
                OutputStream os = c.getOutputStream();
                os.write(Base64.decode(r.getString("body"), Base64.NO_WRAP));
                os.close();
            }
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            byte[] data = in == null ? new byte[0] : readAll(in);
            o.put("status", code);
            o.put("statusText", String.valueOf(c.getResponseMessage()));
            o.put("finalUrl", c.getURL().toString());
            o.put("body", Base64.encodeToString(data, Base64.NO_WRAP));
            log("запрос " + code + ": " + u);
        } catch (Exception e) {
            log("запрос ошибка: " + e);
            try {
                o = new JSONObject();
                o.put("error", String.valueOf(e));
            } catch (Exception ignore) {
            }
        }
        return o.toString();
    }

    class Bridge {
        @JavascriptInterface
        public void request(final String id, final String json) {
            new Thread(() -> {
                final String resp = doRequest(json);
                web.post(() -> web.evaluateJavascript("window.__gmDone('" + id + "'," + resp + ")", null));
            }).start();
        }
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            web.getWebChromeClient().onHideCustomView();
        } else if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
