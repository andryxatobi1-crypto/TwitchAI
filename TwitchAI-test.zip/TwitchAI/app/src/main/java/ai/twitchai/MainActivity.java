package ai.twitchai;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;

public class MainActivity extends Activity {
    static final String START = "https://www.twitch.tv";
    static final String VOT = "https://raw.githubusercontent.com/ilyhalight/voice-over-translation/master/dist/vot.user.js";
    static final String DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
    static final int IMMERSIVE = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;

    WebView web;
    FrameLayout root;
    LinearLayout splash;
    TextView dbg, btn7, btnTr, pcBtn;
    View customView;
    WebChromeClient.CustomViewCallback customCb;
    String shim = "", tai = "", script = "", mobileUa = "";
    boolean desktop = false, splashGone = false;
    final ArrayList<String> lines = new ArrayList<>();

    TextView makeBtn(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(12);
        t.setGravity(Gravity.CENTER);
        t.setBackgroundColor(0xCC6441A5);
        t.setPadding(24, 16, 24, 16);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(0, 0, 0, 12);
        t.setLayoutParams(lp);
        return t;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        root = new FrameLayout(this);
        web = new WebView(this);
        web.setBackgroundColor(0xFF18181B);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        btn7 = makeBtn("7TV");
        btnTr = makeBtn("RU");
        pcBtn = makeBtn("ПК");
        col.addView(btn7);
        col.addView(btnTr);
        col.addView(pcBtn);
        root.addView(col, new FrameLayout.LayoutParams(-2, -2, Gravity.END | Gravity.CENTER_VERTICAL));

        dbg = new TextView(this);
        dbg.setTextSize(10);
        dbg.setTextColor(Color.GREEN);
        dbg.setBackgroundColor(0xAA000000);
        dbg.setPadding(12, 8, 12, 8);
        dbg.setVisibility(View.GONE);
        dbg.setOnClickListener(v -> v.setVisibility(View.GONE));
        root.addView(dbg, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START));

        splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setBackgroundColor(0xFF18181B);
        splash.setClickable(true);
        TextView title = new TextView(this);
        title.setText("TwitchAI");
        title.setTextColor(0xFFBF94FF);
        title.setTextSize(30);
        title.setGravity(Gravity.CENTER);
        ProgressBar pb = new ProgressBar(this);
        pb.getIndeterminateDrawable().setColorFilter(0xFF9146FF, PorterDuff.Mode.SRC_IN);
        splash.addView(title);
        splash.addView(pb);
        root.addView(splash, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        WebView.setWebContentsDebuggingEnabled(true);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        mobileUa = s.getUserAgentString().replace("; wv", "");
        s.setUserAgentString(mobileUa);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        btn7.setOnClickListener(v -> web.evaluateJavascript("window.__tai&&window.__tai.picker()", null));
        btnTr.setOnClickListener(v -> web.evaluateJavascript("window.__tai?String(window.__tai.toggleTr()):'false'", r -> {
            boolean on = r != null && r.contains("true");
            btnTr.setBackgroundColor(on ? 0xCC00875A : 0xCC6441A5);
            log("перевод чата: " + (on ? "вкл" : "выкл"));
        }));
        pcBtn.setOnClickListener(v -> toggleDesktop());
        pcBtn.setOnLongClickListener(v -> {
            dbg.setVisibility(dbg.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            return true;
        });

        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                log("страница: " + url);
                btnTr.setBackgroundColor(0xCC6441A5);
                if (desktop) {
                    v.evaluateJavascript("(function(){var m=document.querySelector('meta[name=viewport]');if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m)}m.setAttribute('content','width=1280')})()", null);
                }
                inject();
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                if (p >= 70) hideSplash();
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage m) {
                String t = m.message();
                int bi = t.lastIndexOf("bold;");
                if (t.startsWith("%cVOT") && bi >= 0) t = "VOT: " + t.substring(bi + 5).trim();
                String tl = t.toLowerCase();
                boolean ours = tl.contains("vot") || tl.contains("gm_") || tl.contains("androidbridge") || tl.contains("yandex") || tl.contains("tai:");
                boolean err = m.messageLevel() == ConsoleMessage.MessageLevel.ERROR && (m.sourceId() == null || m.sourceId().isEmpty());
                if (ours || err) log("[" + m.messageLevel() + "] " + t);
                return true;
            }

            @Override
            public void onShowCustomView(View v, CustomViewCallback cb) {
                customView = v;
                customCb = cb;
                root.addView(v, new FrameLayout.LayoutParams(-1, -1));
                web.setVisibility(View.GONE);
                getWindow().getDecorView().setSystemUiVisibility(IMMERSIVE);
            }

            @Override
            public void onHideCustomView() {
                if (customView == null) return;
                root.removeView(customView);
                customView = null;
                web.setVisibility(View.VISIBLE);
                getWindow().getDecorView().setSystemUiVisibility(0);
                if (customCb != null) customCb.onCustomViewHidden();
            }
        });

        web.postDelayed(this::hideSplash, 12000);
        new Thread(() -> {
            shim = readAsset("shim.js");
            tai = readAsset("tai.js");
            script = readCached();
            boolean cached = !script.isEmpty();
            if (!cached) {
                download();
                script = readCached();
            }
            log("скрипт перевода: " + script.length() + " символов" + (cached ? " (кэш)" : ""));
            runOnUiThread(() -> {
                if (script.isEmpty()) {
                    Toast.makeText(this, "Не удалось загрузить скрипт перевода", Toast.LENGTH_LONG).show();
                }
                web.loadUrl(START);
            });
            if (cached) download();
        }).start();
    }

    void hideSplash() {
        if (splashGone) return;
        splashGone = true;
        splash.animate().alpha(0f).setDuration(400).withEndAction(() -> splash.setVisibility(View.GONE)).start();
    }

    void toggleDesktop() {
        desktop = !desktop;
        WebSettings s = web.getSettings();
        s.setUserAgentString(desktop ? DESKTOP_UA : mobileUa);
        s.setUseWideViewPort(desktop);
        s.setLoadWithOverviewMode(desktop);
        pcBtn.setText(desktop ? "ТЕЛ" : "ПК");
        log("режим: " + (desktop ? "ПК" : "телефон"));
        String u = web.getUrl();
        if (u == null) u = START;
        u = u.replace("?desktop-redirect=true", "");
        if (desktop) u = u.replace("://m.twitch.tv", "://www.twitch.tv");
        web.loadUrl(u);
    }

    void log(final String msg) {
        runOnUiThread(() -> {
            String m = msg.length() > 150 ? msg.substring(0, 150) : msg;
            lines.add(m);
            while (lines.size() > 8) lines.remove(0);
            dbg.setText(TextUtils.join("\n", lines));
        });
    }

    void inject() {
        web.evaluateJavascript("if(!window.__taiInj){window.__taiInj=1;\n" + shim + "\n" + tai
                + "\ntry{\n" + script + "\n}catch(e){console.error('VOT fail: '+e)}\n}", null);
    }

    String readAsset(String name) {
        try {
            return new String(readAll(getAssets().open(name)), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    String readCached() {
        try {
            return new String(readAll(new FileInputStream(new File(getFilesDir(), "vot.js"))), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    void download() {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(VOT).openConnection();
            c.setConnectTimeout(10000);
            c.setReadTimeout(20000);
            byte[] d = readAll(c.getInputStream());
            FileOutputStream fo = new FileOutputStream(new File(getFilesDir(), "vot.js"));
            fo.write(d);
            fo.close();
        } catch (Exception e) {
            // no internet: keep the cached copy
        }
    }

    static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        in.close();
        return o.toByteArray();
    }

    String doRequest(String json) {
        JSONObject o = new JSONObject();
        try {
            JSONObject r = new JSONObject(json);
            String u = r.getString("url");
            if (!u.startsWith("https://")) throw new Exception("https only");
            HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
            c.setRequestMethod(r.optString("method", "GET"));
            c.setConnectTimeout(15000);
            c.setReadTimeout(60000);
            JSONObject h = r.optJSONObject("headers");
            if (h != null) {
                Iterator<String> it = h.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    c.setRequestProperty(k, h.optString(k));
                }
            }
            if (!r.isNull("body")) {
                c.setDoOutput(true);
                OutputStream os = c.getOutputStream();
                os.write(Base64.decode(r.getString("body"), Base64.NO_WRAP));
                os.close();
            }
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            byte[] data = in == null ? new byte[0] : readAll(in);
            o.put("status", code);
            o.put("statusText", String.valueOf(c.getResponseMessage()));
            o.put("finalUrl", c.getURL().toString());
            o.put("body", Base64.encodeToString(data, Base64.NO_WRAP));
            log("запрос " + code + ": " + u);
        } catch (Exception e) {
            log("запрос ошибка: " + e);
            try {
                o = new JSONObject();
                o.put("error", String.valueOf(e));
            } catch (Exception ignore) {
            }
        }
        return o.toString();
    }

    class Bridge {
        @JavascriptInterface
        public void request(final String id, final String json) {
            new Thread(() -> {
                final String resp = doRequest(json);
                web.post(() -> web.evaluateJavascript("window.__gmDone('" + id + "'," + resp + ")", null));
            }).start();
        }
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            web.getWebChromeClient().onHideCustomView();
        } else if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
