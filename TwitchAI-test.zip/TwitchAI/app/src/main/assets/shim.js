(function(){
var P='__gm_',cbs={},n=0;
window.unsafeWindow=window;
window.GM_info={scriptHandler:'TwitchAI',version:'1',script:{name:'vot',version:'1'}};
window.GM_getValue=function(k,d){try{var v=localStorage.getItem(P+k);return v===null?d:JSON.parse(v)}catch(e){return d}};
window.GM_setValue=function(k,v){try{localStorage.setItem(P+k,JSON.stringify(v))}catch(e){}};
window.GM_deleteValue=function(k){try{localStorage.removeItem(P+k)}catch(e){}};
window.GM_listValues=function(){var r=[];for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);if(k.indexOf(P)===0)r.push(k.slice(P.length))}return r};
window.GM_addStyle=function(c){var s=document.createElement('style');s.textContent=c;(document.head||document.documentElement).appendChild(s);return s};
window.GM_registerMenuCommand=function(){};
window.__gmDone=function(id,r){
  var c=cbs[id];delete cbs[id];if(!c)return;
  if(r.error){if(c.onerror)c.onerror({error:r.error,status:0});return}
  var bin=atob(r.body),u=new Uint8Array(bin.length);
  for(var i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);
  var rt=c.responseType||'text',resp;
  try{
    if(rt==='arraybuffer')resp=u.buffer;
    else if(rt==='blob')resp=new Blob([u]);
    else{var t=new TextDecoder().decode(u);resp=rt==='json'?JSON.parse(t):t}
  }catch(e){if(c.onerror)c.onerror({error:String(e),status:0});return}
  var o={status:r.status,statusText:r.statusText,finalUrl:r.finalUrl,readyState:4,response:resp,responseText:typeof resp==='string'?resp:'',responseHeaders:''};
  if(c.onload)c.onload(o);
  if(c.onloadend)c.onloadend(o);
};
function enc(u8){var s='';for(var i=0;i<u8.length;i++)s+=String.fromCharCode(u8[i]);return btoa(s)}
window.GM_xmlhttpRequest=function(d){
  var id=String(++n);cbs[id]=d;
  var send=function(b){AndroidBridge.request(id,JSON.stringify({url:d.url,method:d.method||'GET',headers:d.headers||{},body:b}))};
  var x=d.data!=null?d.data:d.body;
  if(x==null)send(null);
  else if(typeof x==='string')send(btoa(unescape(encodeURIComponent(x))));
  else if(x instanceof Blob){var fr=new FileReader();fr.onload=function(){send(fr.result.split(',')[1])};fr.readAsDataURL(x)}
  else if(x instanceof ArrayBuffer)send(enc(new Uint8Array(x)));
  else send(enc(new Uint8Array(x.buffer,x.byteOffset,x.byteLength)));
  return{abort:function(){delete cbs[id]}};
};
window.GM_xmlHttpRequest=window.GM_xmlhttpRequest;
window.GM={
  info:window.GM_info,
  getValue:function(k,d){return Promise.resolve(GM_getValue(k,d))},
  setValue:function(k,v){GM_setValue(k,v);return Promise.resolve()},
  deleteValue:function(k){GM_deleteValue(k);return Promise.resolve()},
  listValues:function(){return Promise.resolve(GM_listValues())},
  addStyle:function(c){return Promise.resolve(GM_addStyle(c))},
  registerMenuCommand:function(){},
  xmlHttpRequest:function(d){return new Promise(function(res,rej){var o=Object.assign({},d);o.onload=res;o.onerror=rej;o.ontimeout=rej;GM_xmlhttpRequest(o)})}
};
})();
