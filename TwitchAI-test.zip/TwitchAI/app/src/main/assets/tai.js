(function(){
if(window.__tai)return;
var T=window.__tai={emotes:Object.create(null),chan:null,chanNames:[],globNames:[],tr:false,cache:{},q:0};
var done=new WeakSet();
function get(url,opt,cb){
  var d={url:url,method:'GET',responseType:'json',onload:function(r){cb(r.response)},onerror:function(){cb(null)}};
  for(var k in opt)d[k]=opt[k];
  try{GM_xmlhttpRequest(d)}catch(e){cb(null)}
}
function add(list,arr){(list||[]).forEach(function(e){if(e&&e.name&&e.id){T.emotes[e.name]=e.id;arr.push(e.name)}})}
function load(login){
  T.chan=login;T.emotes=Object.create(null);T.chanNames=[];T.globNames=[];
  get('https://7tv.io/v3/emote-sets/global',null,function(j){if(j)add(j.emotes,T.globNames)});
  var byId=function(id){if(id)get('https://7tv.io/v3/users/twitch/'+id,null,function(j){if(j&&j.emote_set)add(j.emote_set.emotes,T.chanNames)})};
  get('https://gql.twitch.tv/gql',{method:'POST',headers:{'Client-ID':'kimne78kx3ncx6brgo4mv6wki5h1ko','Content-Type':'application/json'},data:JSON.stringify({query:'query{user(login:"'+login+'"){id}}'})},function(j){
    var id=j&&j.data&&j.data.user&&j.data.user.id;
    if(id)byId(id);else get('https://api.ivr.fi/v2/twitch/user?login='+login,null,function(a){byId(a&&a[0]&&a[0].id)});
  });
}
var bad={directory:1,videos:1,downloads:1,settings:1,subscriptions:1,wallet:1,inventory:1,friends:1,search:1,u:1,turbo:1,jobs:1,p:1,store:1,popout:1,moderator:1};
function chanFromPath(){var m=location.pathname.match(/^\/([A-Za-z0-9_]{3,25})\/?$/);return m&&!bad[m[1].toLowerCase()]?m[1]:null}
function tick(){var c=chanFromPath();if(c&&c!==T.chan)load(c)}
tick();setInterval(tick,2000);

function img(id,name){
  var i=document.createElement('img');
  i.src='https://cdn.7tv.app/emote/'+id+'/2x.webp';i.alt=name;i.title=name;i.className='tai-emote';
  i.style.cssText='height:28px;vertical-align:middle;margin:0 2px';
  return i;
}
function inChatEl(e){
  var i=0;
  while(e&&i++<10){
    var s=(typeof e.className==='string'?e.className:'')+' '+(e.getAttribute('data-a-target')||'')+' '+(e.getAttribute('data-test-selector')||'');
    if(/chat/i.test(s))return true;
    e=e.parentElement;
  }
  return false;
}
function skip(n){var p=n.parentElement;return !p||/^(SCRIPT|STYLE|TEXTAREA|INPUT)$/.test(p.tagName)||p.isContentEditable||!!p.closest('.tai-skip,.tai-tr')}
function show(n,s){if(!n.parentNode||!T.tr)return;var sp=document.createElement('span');sp.className='tai-tr';sp.style.cssText='color:#bf94ff;margin-left:6px';sp.textContent='→ '+s;n.parentNode.insertBefore(sp,n.nextSibling)}
function tr(n){
  var t=n.nodeValue.trim();
  if(t.length<8||t.indexOf(' ')<0)return;
  if((t.match(/[\u0400-\u04FF]/g)||[]).length>t.length*0.3)return;
  if(T.cache[t]){show(n,T.cache[t]);return}
  if(T.q>6)return;
  T.q++;
  get('https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=ru&dt=t&q='+encodeURIComponent(t),null,function(j){
    T.q--;
    try{var s=j[0].map(function(x){return x[0]}).join('');if(s&&s!==t){T.cache[t]=s;show(n,s)}}catch(e){}
  });
}
function proc(n){
  if(done.has(n))return;done.add(n);
  var t=n.nodeValue;if(!t||t.length<2)return;
  var parts=t.split(/(\s+)/),hit=false;
  for(var i=0;i<parts.length;i++){if(T.emotes[parts[i]]!==undefined){hit=true;break}}
  if(hit){
    var f=document.createDocumentFragment(),buf='';
    var flush=function(){if(buf){var tn=document.createTextNode(buf);done.add(tn);f.appendChild(tn);buf=''}};
    parts.forEach(function(p){if(T.emotes[p]!==undefined){flush();f.appendChild(img(T.emotes[p],p))}else buf+=p});
    flush();
    n.parentNode.replaceChild(f,n);
    return;
  }
  if(T.tr)tr(n);
}
function walk(node){
  if(node.nodeType===3){if(!skip(node)&&inChatEl(node.parentElement))proc(node);return}
  if(node.nodeType!==1||/^(SCRIPT|STYLE)$/.test(node.tagName))return;
  if(!inChatEl(node)&&!node.querySelector('[class*="chat" i],[data-a-target*="chat" i]'))return;
  var w=document.createTreeWalker(node,NodeFilter.SHOW_TEXT),x,list=[];
  while((x=w.nextNode()))list.push(x);
  list.forEach(function(t){if(!skip(t)&&inChatEl(t.parentElement))proc(t)});
}
new MutationObserver(function(ms){ms.forEach(function(m){m.addedNodes.forEach(function(n){try{walk(n)}catch(e){console.log('TAI: '+e)}})})}).observe(document.documentElement,{childList:true,subtree:true});

function insert(nm){
  var el=document.querySelector('[data-a-target="chat-input"]')||document.querySelector('div[contenteditable="true"]')||document.querySelector('textarea')||document.querySelector('input[type="text"]');
  if(!el)return;
  el.focus();
  if(el.tagName==='TEXTAREA'||el.tagName==='INPUT'){
    var d=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el),'value');
    d.set.call(el,(el.value?el.value+' ':'')+nm+' ');
    el.dispatchEvent(new Event('input',{bubbles:true}));
  }else document.execCommand('insertText',false,nm+' ');
}
T.picker=function(){
  var p=document.getElementById('tai-pick');
  if(p){p.remove();return}
  p=document.createElement('div');p.id='tai-pick';p.className='tai-skip';
  p.style.cssText='position:fixed;left:0;right:0;bottom:0;height:40%;background:#18181b;border-top:2px solid #9146ff;z-index:2147483647;overflow:auto;padding:8px;display:flex;flex-wrap:wrap;align-content:flex-start;gap:6px;color:#fff;font:14px sans-serif';
  var names=T.chanNames.concat(T.globNames).slice(0,500);
  if(!names.length)p.textContent='7TV смайлики ещё не загрузились. Открой канал и подожди пару секунд.';
  names.forEach(function(nm){var i=img(T.emotes[nm],nm);i.style.height='36px';i.addEventListener('click',function(){insert(nm)});p.appendChild(i)});
  document.body.appendChild(p);
};
T.toggleTr=function(){T.tr=!T.tr;return T.tr};
})();
